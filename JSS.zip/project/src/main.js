import { subscribeToAuthChanges } from './services/auth.js';
import { initializeAuth } from './views/auth.js';
import { initializeDashboard } from './views/dashboard.js';

// Initialize the application
const init = () => {
  const authContainer = document.getElementById('auth-container');
  const dashboardContainer = document.getElementById('dashboard-container');

  // Initialize views
  initializeAuth(authContainer);
  initializeDashboard(dashboardContainer);

  // Subscribe to auth state changes
  subscribeToAuthChanges((user) => {
    if (user) {
      authContainer.classList.add('hidden');
      dashboardContainer.classList.remove('hidden');
    } else {
      authContainer.classList.remove('hidden');
      dashboardContainer.classList.add('hidden');
    }
  });
};

// Start the application
document.addEventListener('DOMContentLoaded', init);