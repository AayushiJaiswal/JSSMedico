import { getUserProfile, updateUserProfile } from '../services/users.js';
import { auth } from '../config/firebase.js';

export const renderProfileTab = async (container) => {
  const user = auth.currentUser;
  const profile = await getUserProfile(user.uid);

  container.innerHTML = `
    <div class="profile-container">
      <h2>Profile</h2>
      
      <form id="profile-form" class="profile-form">
        <div class="form-group">
          <label for="fullName">Full Name</label>
          <input type="text" id="fullName" value="${profile.fullName}" required>
        </div>
        
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" value="${profile.email}" disabled>
        </div>
        
        <div class="form-group">
          <label for="userType">User Type</label>
          <input type="text" id="userType" value="${profile.userType}" disabled>
        </div>
        
        ${profile.userType === 'doctor' ? `
          <div class="form-group">
            <label for="specialization">Specialization</label>
            <input type="text" id="specialization" value="${profile.specialization || ''}">
          </div>
          
          <div class="form-group">
            <label for="experience">Years of Experience</label>
            <input type="number" id="experience" value="${profile.experience || 0}">
          </div>
        ` : ''}
        
        <div class="form-group">
          <label for="phone">Phone Number</label>
          <input type="tel" id="phone" value="${profile.phone || ''}">
        </div>
        
        <div class="form-group">
          <label for="address">Address</label>
          <textarea id="address" rows="3">${profile.address || ''}</textarea>
        </div>
        
        <button type="submit" class="btn">Update Profile</button>
      </form>
    </div>
  `;

  // Handle profile updates
  const profileForm = document.getElementById('profile-form');
  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const updatedProfile = {
      fullName: document.getElementById('fullName').value,
      phone: document.getElementById('phone').value,
      address: document.getElementById('address').value
    };

    if (profile.userType === 'doctor') {
      updatedProfile.specialization = document.getElementById('specialization').value;
      updatedProfile.experience = parseInt(document.getElementById('experience').value);
    }

    try {
      await updateUserProfile(user.uid, updatedProfile);
      alert('Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Failed to update profile');
    }
  });
};