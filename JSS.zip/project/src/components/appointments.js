import { format } from 'date-fns';
import { createAppointment, getPatientAppointments, getDoctorAppointments } from '../services/appointments.js';
import { getDoctors } from '../services/users.js';
import { auth } from '../config/firebase.js';

export const renderAppointmentsTab = async (container) => {
  const user = auth.currentUser;
  const userProfile = await getUserProfile(user.uid);
  const isDoctor = userProfile.userType === 'doctor';

  container.innerHTML = `
    <div class="appointments-container">
      <div class="appointments-header">
        <h2>Appointments</h2>
        ${!isDoctor ? '<button id="new-appointment-btn" class="btn">New Appointment</button>' : ''}
      </div>
      
      <div id="appointment-form" class="appointment-form hidden">
        <h3>Schedule New Appointment</h3>
        <form id="create-appointment-form">
          <div class="form-group">
            <label for="doctor">Select Doctor</label>
            <select id="doctor" required></select>
          </div>
          <div class="form-group">
            <label for="date">Date</label>
            <input type="date" id="date" required min="${new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label for="time">Time</label>
            <input type="time" id="time" required>
          </div>
          <div class="form-group">
            <label for="type">Appointment Type</label>
            <select id="type" required>
              <option value="consultation">Consultation</option>
              <option value="follow-up">Follow-up</option>
              <option value="emergency">Emergency</option>
            </select>
          </div>
          <div class="form-group">
            <label for="notes">Notes</label>
            <textarea id="notes" rows="3"></textarea>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn">Schedule</button>
            <button type="button" class="btn btn-secondary" id="cancel-appointment">Cancel</button>
          </div>
        </form>
      </div>

      <div id="appointments-list" class="appointments-list">
        <div class="loading">Loading appointments...</div>
      </div>
    </div>
  `;

  // Load doctors for the appointment form
  if (!isDoctor) {
    const doctors = await getDoctors();
    const doctorSelect = document.getElementById('doctor');
    doctorSelect.innerHTML = doctors.map(doctor => 
      `<option value="${doctor.id}">${doctor.fullName}</option>`
    ).join('');
  }

  // Handle new appointment form
  const newAppointmentBtn = document.getElementById('new-appointment-btn');
  const appointmentForm = document.getElementById('appointment-form');
  const cancelAppointmentBtn = document.getElementById('cancel-appointment');

  if (newAppointmentBtn) {
    newAppointmentBtn.addEventListener('click', () => {
      appointmentForm.classList.remove('hidden');
    });
  }

  if (cancelAppointmentBtn) {
    cancelAppointmentBtn.addEventListener('click', () => {
      appointmentForm.classList.add('hidden');
    });
  }

  // Handle appointment creation
  const createAppointmentForm = document.getElementById('create-appointment-form');
  if (createAppointmentForm) {
    createAppointmentForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = {
        doctorId: document.getElementById('doctor').value,
        userId: user.uid,
        dateTime: new Date(`${document.getElementById('date').value}T${document.getElementById('time').value}`).toISOString(),
        type: document.getElementById('type').value,
        notes: document.getElementById('notes').value,
        status: 'pending'
      };

      try {
        await createAppointment(formData);
        appointmentForm.classList.add('hidden');
        loadAppointments();
      } catch (error) {
        console.error('Error creating appointment:', error);
        alert('Failed to create appointment');
      }
    });
  }

  // Load appointments
  const loadAppointments = async () => {
    const appointmentsList = document.getElementById('appointments-list');
    try {
      const appointments = isDoctor ? 
        await getDoctorAppointments(user.uid) : 
        await getPatientAppointments(user.uid);

      appointmentsList.innerHTML = appointments.length ? 
        appointments.map(appointment => `
          <div class="appointment-card ${appointment.status}">
            <div class="appointment-header">
              <h3>${format(new Date(appointment.dateTime), 'PPP')}</h3>
              <span class="status-badge ${appointment.status}">${appointment.status}</span>
            </div>
            <div class="appointment-details">
              <p><strong>Time:</strong> ${format(new Date(appointment.dateTime), 'p')}</p>
              <p><strong>Type:</strong> ${appointment.type}</p>
              ${appointment.notes ? `<p><strong>Notes:</strong> ${appointment.notes}</p>` : ''}
            </div>
          </div>
        `).join('') :
        '<p class="no-data">No appointments found.</p>';
    } catch (error) {
      console.error('Error loading appointments:', error);
      appointmentsList.innerHTML = '<p class="error">Error loading appointments</p>';
    }
  };

  loadAppointments();
};