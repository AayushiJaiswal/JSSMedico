import { createMedicalRecord, getPatientRecords } from '../services/medical-records.js';
import { auth } from '../config/firebase.js';
import { getUserProfile } from '../services/users.js';
import { format } from 'date-fns';

export const renderMedicalRecordsTab = async (container) => {
  const user = auth.currentUser;
  const userProfile = await getUserProfile(user.uid);
  const isDoctor = userProfile.userType === 'doctor';

  container.innerHTML = `
    <div class="medical-records-container">
      <div class="medical-records-header">
        <h2>Medical Records</h2>
        ${isDoctor ? '<button id="new-record-btn" class="btn">New Record</button>' : ''}
      </div>

      ${isDoctor ? `
        <div id="record-form" class="record-form hidden">
          <h3>Create Medical Record</h3>
          <form id="create-record-form">
            <div class="form-group">
              <label for="patientId">Patient ID</label>
              <input type="text" id="patientId" required>
            </div>
            <div class="form-group">
              <label for="diagnosis">Diagnosis</label>
              <input type="text" id="diagnosis" required>
            </div>
            <div class="form-group">
              <label for="prescription">Prescription</label>
              <textarea id="prescription" rows="3" required></textarea>
            </div>
            <div class="form-group">
              <label for="notes">Notes</label>
              <textarea id="notes" rows="3"></textarea>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn">Create Record</button>
              <button type="button" class="btn btn-secondary" id="cancel-record">Cancel</button>
            </div>
          </form>
        </div>
      ` : ''}

      <div id="medical-records-list" class="medical-records-list">
        <div class="loading">Loading medical records...</div>
      </div>
    </div>
  `;

  // Handle new record form for doctors
  if (isDoctor) {
    const newRecordBtn = document.getElementById('new-record-btn');
    const recordForm = document.getElementById('record-form');
    const cancelRecordBtn = document.getElementById('cancel-record');

    newRecordBtn.addEventListener('click', () => {
      recordForm.classList.remove('hidden');
    });

    cancelRecordBtn.addEventListener('click', () => {
      recordForm.classList.add('hidden');
    });

    // Handle record creation
    const createRecordForm = document.getElementById('create-record-form');
    createRecordForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = {
        patientId: document.getElementById('patientId').value,
        doctorId: user.uid,
        diagnosis: document.getElementById('diagnosis').value,
        prescription: document.getElementById('prescription').value,
        notes: document.getElementById('notes').value
      };

      try {
        await createMedicalRecord(formData);
        recordForm.classList.add('hidden');
        loadMedicalRecords();
      } catch (error) {
        console.error('Error creating medical record:', error);
        alert('Failed to create medical record');
      }
    });
  }

  // Load medical records
  const loadMedicalRecords = async () => {
    const recordsList = document.getElementById('medical-records-list');
    try {
      const records = await getPatientRecords(isDoctor ? null : user.uid);
      
      recordsList.innerHTML = records.length ? 
        records.map(record => `
          <div class="record-card">
            <div class="record-header">
              <h3>Record from ${format(new Date(record.createdAt), 'PPP')}</h3>
            </div>
            <div class="record-details">
              <p><strong>Diagnosis:</strong> ${record.diagnosis}</p>
              <p><strong>Prescription:</strong> ${record.prescription}</p>
              ${record.notes ? `<p><strong>Notes:</strong> ${record.notes}</p>` : ''}
            </div>
          </div>
        `).join('') :
        '<p class="no-data">No medical records found.</p>';
    } catch (error) {
      console.error('Error loading medical records:', error);
      recordsList.innerHTML = '<p class="error">Error loading medical records</p>';
    }
  };

  loadMedicalRecords();
};