import { sendMessage, subscribeToMessages } from '../services/messages.js';
import { getDoctors, getUserProfile } from '../services/users.js';
import { auth } from '../config/firebase.js';
import { format } from 'date-fns';

export const renderMessagesTab = async (container) => {
  const user = auth.currentUser;
  const userProfile = await getUserProfile(user.uid);
  const isDoctor = userProfile.userType === 'doctor';

  container.innerHTML = `
    <div class="messages-container">
      <div class="messages-sidebar">
        <h3>Contacts</h3>
        <div id="contacts-list" class="contacts-list">
          <div class="loading">Loading contacts...</div>
        </div>
      </div>
      
      <div class="messages-main">
        <div id="chat-header" class="chat-header">
          <h3>Select a contact to start messaging</h3>
        </div>
        
        <div id="messages-list" class="messages-list"></div>
        
        <div id="message-form" class="message-form hidden">
          <form id="send-message-form">
            <input type="text" id="message-input" placeholder="Type your message..." required>
            <button type="submit" class="btn">Send</button>
          </form>
        </div>
      </div>
    </div>
  `;

  // Load contacts
  const loadContacts = async () => {
    const contactsList = document.getElementById('contacts-list');
    try {
      const contacts = isDoctor ? await getPatients() : await getDoctors();
      
      contactsList.innerHTML = contacts.map(contact => `
        <div class="contact-item" data-id="${contact.id}">
          <div class="contact-info">
            <h4>${contact.fullName}</h4>
            <p>${contact.email}</p>
          </div>
        </div>
      `).join('');

      // Add click handlers for contacts
      document.querySelectorAll('.contact-item').forEach(item => {
        item.addEventListener('click', () => {
          document.querySelectorAll('.contact-item').forEach(i => i.classList.remove('active'));
          item.classList.add('active');
          initializeChat(item.dataset.id);
        });
      });
    } catch (error) {
      console.error('Error loading contacts:', error);
      contactsList.innerHTML = '<p class="error">Error loading contacts</p>';
    }
  };

  // Initialize chat with selected contact
  const initializeChat = (recipientId) => {
    const messagesList = document.getElementById('messages-list');
    const messageForm = document.getElementById('message-form');
    const chatHeader = document.getElementById('chat-header');

    messagesList.innerHTML = '';
    messageForm.classList.remove('hidden');

    // Subscribe to messages
    const unsubscribe = subscribeToMessages(user.uid, (messages) => {
      messagesList.innerHTML = messages.map(message => `
        <div class="message ${message.senderId === user.uid ? 'sent' : 'received'}">
          <div class="message-content">
            <p>${message.content}</p>
            <span class="message-time">${format(new Date(message.createdAt), 'p')}</span>
          </div>
        </div>
      `).join('');
      
      messagesList.scrollTop = messagesList.scrollHeight;
    });

    // Handle message sending
    const sendMessageForm = document.getElementById('send-message-form');
    sendMessageForm.onsubmit = async (e) => {
      e.preventDefault();
      const input = document.getElementById('message-input');
      const content = input.value.trim();
      
      if (content) {
        try {
          await sendMessage(user.uid, recipientId, content);
          input.value = '';
        } catch (error) {
          console.error('Error sending message:', error);
          alert('Failed to send message');
        }
      }
    };

    return unsubscribe;
  };

  loadContacts();
};