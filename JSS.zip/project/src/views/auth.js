import { registerUser, loginUser } from '../services/auth.js';

export const initializeAuth = (container) => {
  container.innerHTML = `
    <div class="auth-forms">
      <div class="login-form">
        <h2>Login</h2>
        <form id="login-form">
          <div class="form-group">
            <label for="login-email">Email</label>
            <input type="email" id="login-email" required>
          </div>
          <div class="form-group">
            <label for="login-password">Password</label>
            <input type="password" id="login-password" required>
          </div>
          <button type="submit" class="btn">Login</button>
        </form>
      </div>

      <div class="register-form">
        <h2>Register</h2>
        <form id="register-form">
          <div class="form-group">
            <label for="register-email">Email</label>
            <input type="email" id="register-email" required>
          </div>
          <div class="form-group">
            <label for="register-password">Password</label>
            <input type="password" id="register-password" required>
          </div>
          <div class="form-group">
            <label for="full-name">Full Name</label>
            <input type="text" id="full-name" required>
          </div>
          <div class="form-group">
            <label for="user-type">User Type</label>
            <select id="user-type" required>
              <option value="patient">Patient</option>
              <option value="doctor">Doctor</option>
            </select>
          </div>
          <button type="submit" class="btn">Register</button>
        </form>
      </div>
    </div>
  `;

  // Handle login form submission
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
      await loginUser(email, password);
    } catch (error) {
      console.error('Login error:', error);
      alert(error.message);
    }
  });

  // Handle registration form submission
  document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const fullName = document.getElementById('full-name').value;
    const userType = document.getElementById('user-type').value;

    try {
      await registerUser(email, password, userType, fullName);
    } catch (error) {
      console.error('Registration error:', error);
      alert(error.message);
    }
  });
};