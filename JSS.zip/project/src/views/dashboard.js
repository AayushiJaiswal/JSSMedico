import { auth } from '../config/firebase.js';
import { logoutUser } from '../services/auth.js';
import { renderAppointmentsTab } from '../components/appointments.js';
import { renderMedicalRecordsTab } from '../components/medical-records.js';
import { renderMessagesTab } from '../components/messages.js';
import { renderProfileTab } from '../components/profile.js';
import { getUserProfile } from '../services/users.js';

export const initializeDashboard = (container) => {
  const renderDashboard = async () => {
    const user = auth.currentUser;
    if (!user) return;

    container.innerHTML = `
      <header class="dashboard-header">
        <h1>Welcome to JSSMedico</h1>
        <button id="logout-btn" class="btn">Logout</button>
      </header>
      
      <nav class="dashboard-nav">
        <button class="tab-btn active" data-tab="appointments">Appointments</button>
        <button class="tab-btn" data-tab="medical-records">Medical Records</button>
        <button class="tab-btn" data-tab="messages">Messages</button>
        <button class="tab-btn" data-tab="profile">Profile</button>
      </nav>

      <main class="dashboard-content">
        <div id="appointments-tab" class="tab-content active"></div>
        <div id="medical-records-tab" class="tab-content hidden"></div>
        <div id="messages-tab" class="tab-content hidden"></div>
        <div id="profile-tab" class="tab-content hidden"></div>
      </main>
    `;

    // Initialize first tab
    await renderAppointmentsTab(document.getElementById('appointments-tab'));

    // Handle logout
    document.getElementById('logout-btn').addEventListener('click', async () => {
      try {
        await logoutUser();
      } catch (error) {
        console.error('Logout error:', error);
        alert(error.message);
      }
    });

    // Handle tab switching
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
      button.addEventListener('click', async () => {
        const tabName = button.dataset.tab;
        
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        button.classList.add('active');
        const tabContent = document.getElementById(`${tabName}-tab`);
        tabContent.classList.add('active');

        // Render tab content
        switch (tabName) {
          case 'appointments':
            await renderAppointmentsTab(tabContent);
            break;
          case 'medical-records':
            await renderMedicalRecordsTab(tabContent);
            break;
          case 'messages':
            await renderMessagesTab(tabContent);
            break;
          case 'profile':
            await renderProfileTab(tabContent);
            break;
        }
      });
    });
  };

  // Initial render
  renderDashboard();
};