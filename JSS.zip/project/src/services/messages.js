import { 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../config/firebase.js';

export const sendMessage = async (senderId, recipientId, content) => {
  try {
    await addDoc(collection(db, 'messages'), {
      senderId,
      recipientId,
      content,
      createdAt: new Date().toISOString(),
      read: false
    });
  } catch (error) {
    throw error;
  }
};

export const getMessages = async (userId) => {
  try {
    const q = query(
      collection(db, 'messages'),
      where('recipientId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    throw error;
  }
};

export const subscribeToMessages = (userId, callback) => {
  const q = query(
    collection(db, 'messages'),
    where('recipientId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  
  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    callback(messages);
  });
};