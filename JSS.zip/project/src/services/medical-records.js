import { 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs,
  orderBy 
} from 'firebase/firestore';
import { db } from '../config/firebase.js';

export const createMedicalRecord = async (recordData) => {
  try {
    const docRef = await addDoc(collection(db, 'medical_records'), {
      ...recordData,
      createdAt: new Date().toISOString()
    });
    return docRef.id;
  } catch (error) {
    throw error;
  }
};

export const getPatientRecords = async (patientId) => {
  try {
    const q = query(
      collection(db, 'medical_records'),
      where('patientId', '==', patientId),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    throw error;
  }
};