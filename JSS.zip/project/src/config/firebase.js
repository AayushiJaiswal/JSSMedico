import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCz02_uU8YhcHvYLWtJu0Y1yt86IyAZXu8",
  authDomain: "jssmedico-ae72c.firebaseapp.com",
  projectId: "jssmedico-ae72c",
  storageBucket: "jssmedico-ae72c.firebasestorage.app",
  messagingSenderId: "1040203009569",
  appId: "1:1040203009569:web:4f22a0acefee8cc8191d60"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);